import { useEffect, useState } from "react";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { auth0Client } from "../lib/auth0";

const dummyArtists = [
  {
    name: "DJ Echo",
    role: "Producer",
    lastUpload: "2025-05-10",
    profileLink: "/profile/echo",
  },
  {
    name: "MC Nova",
    role: "Vocalist",
    lastUpload: "2025-05-15",
    profileLink: "/profile/nova",
  },
  {
    name: "Synth Shadow",
    role: "Composer",
    lastUpload: "2025-04-30",
    profileLink: "/profile/shadow",
  },
];

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadStatus, setUploadStatus] = useState("");
  const [uploadedFiles, setUploadedFiles] = useState([]);

  useEffect(() => {
    auth0Client.getUser().then(setUser);
  }, []);

  useEffect(() => {
    if (user) {
      fetch(`/api/files?user=${user.email}`)
        .then((res) => res.json())
        .then(setUploadedFiles);
    }
  }, [user]);

  const handleFileChange = (e) => {
    setSelectedFile(e.target.files[0]);
  };

  const handleFileUpload = async () => {
    if (!selectedFile) return;

    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("uploader", user.email);

    try {
      const response = await fetch("https://vps.yourlabel.com/upload", {
        method: "POST",
        body: formData,
      });
      if (response.ok) {
        setUploadStatus("✅ Upload successful");
        setSelectedFile(null);
      } else {
        setUploadStatus("❌ Upload failed");
      }
    } catch (err) {
      setUploadStatus("❌ Error uploading file");
    }
  };

  if (!user) {
    return (
      <div className="p-10 text-center">
        <h1 className="text-2xl font-bold mb-4">Please log in to access the portal.</h1>
        <Button onClick={() => auth0Client.loginWithRedirect()}>Login</Button>
      </div>
    );
  }

  const isAdmin = user.email.endsWith("@yourlabel.com");

  return (
    <div className="p-6 grid gap-6">
      <h1 className="text-3xl font-bold">Welcome, {user.name}!</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent>
            <h2 className="text-xl font-semibold">🎵 Downloads</h2>
            <p>Access label files securely.</p>
            <a href="https://files.backend.yourlabel.com" target="_blank" rel="noopener noreferrer">
              <Button className="mt-2">Open File Portal</Button>
            </a>
          </CardContent>
        </Card>
        <Card>
          <CardContent>
            <h2 className="text-xl font-semibold">📢 Announcements</h2>
            <p>Read the latest label updates.</p>
            <a href="/announcements">
              <Button className="mt-2">Go to Announcements</Button>
            </a>
          </CardContent>
        </Card>
        <Card>
          <CardContent>
            <h2 className="text-xl font-semibold">📄 Artist Profile</h2>
            <p>View or update your profile.</p>
            <a href="/profile">
              <Button className="mt-2">Edit Profile</Button>
            </a>
          </CardContent>
        </Card>
      </div>

      <div className="mt-10">
        <h2 className="text-2xl font-semibold mb-4">⬆️ Upload Your Files</h2>
        <div className="border border-gray-300 rounded p-4">
          <input type="file" onChange={handleFileChange} className="mb-4" />
          <Button onClick={handleFileUpload} disabled={!selectedFile}>
            Upload File
          </Button>
          {uploadStatus && <p className="mt-2 text-sm">{uploadStatus}</p>}
          <p className="text-xs text-gray-500 mt-2">
            Only admins and you can access your uploaded files.
          </p>
        </div>
      </div>

      <div className="mt-10">
        <h2 className="text-2xl font-semibold mb-4">📁 Your Uploaded Files</h2>
        <ul className="list-disc list-inside">
          {uploadedFiles.map((file, idx) => (
            <li key={idx}>
              <a href={file.url} target="_blank" rel="noopener noreferrer" className="text-blue-500">
                {file.name}
              </a>
            </li>
          ))}
        </ul>
      </div>

      {isAdmin && (
        <div className="mt-10">
          <h2 className="text-2xl font-semibold mb-4">🛠 Admin Panel</h2>
          <div className="border border-gray-300 rounded p-4">
            <p>View and manage all artist uploads.</p>
            <a href="/admin/files">
              <Button className="mt-2">Open File Manager</Button>
            </a>
          </div>
        </div>
      )}

      <div className="mt-10">
        <h2 className="text-2xl font-semibold mb-4">🎤 Artist Dashboards</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {dummyArtists.map((artist, index) => (
            <Card key={index}>
              <CardContent>
                <h3 className="text-lg font-bold">{artist.name}</h3>
                <p className="text-sm">Role: {artist.role}</p>
                <p className="text-sm">Last Upload: {artist.lastUpload}</p>
                <a href={artist.profileLink}>
                  <Button className="mt-2">View Dashboard</Button>
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}